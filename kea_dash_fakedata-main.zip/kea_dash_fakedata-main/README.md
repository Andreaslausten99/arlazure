# kea_dash_fakedata
Demo af Dash med data fra en Excel fil - Deploy på Azure
